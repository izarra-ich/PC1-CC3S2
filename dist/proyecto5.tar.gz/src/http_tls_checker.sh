#!/bin/bash
echo "Simulación de chequeo HTTP"
exit 0
