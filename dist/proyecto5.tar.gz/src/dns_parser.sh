#!/bin/bash
echo "Simulación de chequeo DNS"
exit 0
